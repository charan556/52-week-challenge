package com.prokarma.jms.training;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class Publisher {
	// URL of the JMS server.
	private static final String URL = ActiveMQConnection.DEFAULT_BROKER_URL;

	private static String TOPIC_NAME = "SAMPLE_TOPIC";

	public void sendMessage(String messageText) throws JMSException {
		// Getting JMS connection from the server and starting it
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(URL);
		Connection connection = connectionFactory.createConnection();
		connection.start();

		// JMS messages are sent and received using a Session.
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);

		// Destination represents here our TOPIC 'SAMPLE_TOPIC' on the
		// JMS server. You don't have to do anything special on the
		// server to create it, it will be created automatically.
		Destination destination = session.createTopic(TOPIC_NAME);

		// MessageProducer is used for sending messages
		MessageProducer producer = session.createProducer(destination);

		// There are many types of Message and TextMessage
		// is just one of them.
		TextMessage message = session.createTextMessage(messageText);

		// Here we are sending the message!
		producer.send(message);
		System.out.println("Sent message '" + message.getText() + "'");

		connection.close();
	}

	public static void main(String[] args) throws JMSException {
		Publisher publisher = new Publisher();
		publisher.sendMessage("Hello");
	}

}