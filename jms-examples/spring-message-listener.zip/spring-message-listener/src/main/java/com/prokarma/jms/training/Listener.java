package com.prokarma.jms.training;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Listener implements MessageListener {

	public void onMessage(Message message) {
		try {
			if (message instanceof TextMessage) {
				TextMessage textMessage = (TextMessage) message;
				System.out.println("Received message '" + textMessage.getText()
						+ "'");

			}
		} catch (JMSException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws InterruptedException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"listener-context.xml");
		Thread.sleep(1000);
		context.close();

	}

}