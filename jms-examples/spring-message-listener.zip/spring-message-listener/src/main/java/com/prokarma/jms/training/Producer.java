package com.prokarma.jms.training;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

public class Producer {
	// URL of the JMS server.
	private final JmsTemplate template;

	public Producer(JmsTemplate template) {
		this.template = template;
	}

	public void sendMessage(final String messageText) {
		template.send(new MessageCreator() {

			public Message createMessage(Session session) throws JMSException {
				System.out.println("Sent message '" + messageText + "'");
				return session.createTextMessage(messageText);

			}

		});
	}

	public static void main(String[] args) throws InterruptedException {
		final ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"producer-context.xml");

		Producer obj = (Producer) context.getBean("producer");
		obj.sendMessage("Hello");
		Thread.sleep(1000);
		context.close();

	}

}