package com.prokarma.spring.jms.training.service;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageService {

	
	public static void main(String[] args) throws InterruptedException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"listener-context.xml");
		Thread.sleep(1000);
		context.close();

	}

}