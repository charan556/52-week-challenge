package com.prokarma.spring.jms.training.service;

public class ServiceProvider {
	public String process(String id) {

		System.out.println("ID" + id);
		// *Retrieve details from db or some storage and construct reply
		// message
		return "Successfully Processed " + id;

	}


}
