package com.prokarma.jms.training.service;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class MessageService {
	// URL of the JMS server
	private static final String URL = ActiveMQConnection.DEFAULT_BROKER_URL;

	// Name of the queue we will receive messages from
	private static String QUEUE_NAME = "SAMPLE_QUEUE";

	public void processMessage() throws JMSException, InterruptedException {
		// Getting JMS connection from the server
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(URL);
		Connection connection = connectionFactory.createConnection();
		connection.start();

		// Creating session for seding messages
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);

		// Getting the queue 'SAMPLE_QUEUE'
		Destination destination = session.createQueue(QUEUE_NAME);

		// MessageConsumer is used for receiving messages
		MessageConsumer consumer = session.createConsumer(destination);

		// set an asynchronous message listener
		consumer.setMessageListener(new AsynchronousMessageListener(session));

		// wait for messages
		System.out.print("waiting for messages");
		for (int i = 0; i < 100; i++) {
			Thread.sleep(1000);
			System.out.print(".");
		}
		System.out.println();

		connection.close();

	}

	public static void main(String[] args) throws JMSException,
			InterruptedException {
		MessageService consumer = new MessageService();
		consumer.processMessage();
	}

}