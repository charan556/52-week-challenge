package com.prokarma.jms.training;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class Subscriber {
	// URL of the JMS server
	private static final String URL = ActiveMQConnection.DEFAULT_BROKER_URL;

	private static String TOPIC_NAME = "SAMPLE_TOPIC";

	public String recieveMessage(String clientID) throws JMSException {
		// Getting JMS connection from the server
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(URL);
		Connection connection = connectionFactory.createConnection();
		connection.setClientID(clientID);
		connection.start();

		// Creating session for seding messages
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
	
		// Getting the destination 'SAMPLE_TOPIC'
		Topic destination = session.createTopic(TOPIC_NAME);

		// MessageConsumer is used for receiving messages
		MessageConsumer consumer = session.createDurableSubscriber(destination,
				"mysub");

		// Here we receive the message.
		// By default this call blocks the flow
		Message message = consumer.receive();

		// There are many types of Message and TextMessage
		// is just one of them. Producer sent us a TextMessage
		// so we must cast to it to get access to its .getText()
		// method.
		String text = null;
		if (message instanceof TextMessage) {
			TextMessage textMessage = (TextMessage) message;
			text = textMessage.getText();
		}
		connection.close();
		return text;
	}

	public static void main(String[] args) throws JMSException {
		Subscriber consumer = new Subscriber();
		System.out.println("Received message '" + consumer.recieveMessage("Client1")
				+ "'");
	}

}