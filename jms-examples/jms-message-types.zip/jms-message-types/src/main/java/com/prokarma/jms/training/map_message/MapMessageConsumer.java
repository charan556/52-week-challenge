package com.prokarma.jms.training.map_message;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class MapMessageConsumer {
	// URL of the JMS server
	private static final String URL = ActiveMQConnection.DEFAULT_BROKER_URL;

	// Name of the queue we will receive messages from
	private static String QUEUE_NAME = "SAMPLE_QUEUE";

	public String recieveMessage() throws JMSException {
		// Getting JMS connection from the server
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(URL);
		Connection connection = connectionFactory.createConnection();
		connection.start();

		// Creating session for seding messages
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);

		// Getting the queue 'SAMPLE_QUEUE'
		Destination destination = session.createQueue(QUEUE_NAME);

		// MessageConsumer is used for receiving messages
		MessageConsumer consumer = session.createConsumer(destination);

		// Here we receive the message.
		// By default this call blocks the flow
		Message message = consumer.receive();

		// There are many types of Message and TextMessage
		// is just one of them. Producer sent us a TextMessage
		// so we must cast to it to get access to its .getText()
		// method.
		String text = null;
		if (message instanceof MapMessage) {
			MapMessage textMessage = (MapMessage) message;
			text = textMessage.getString("messageText");
		}
		connection.close();
		return text;
	}

	public static void main(String[] args) throws JMSException {
		MapMessageConsumer consumer = new MapMessageConsumer();
		System.out.println("Received message '" + consumer.recieveMessage()
				+ "'");
	}

}