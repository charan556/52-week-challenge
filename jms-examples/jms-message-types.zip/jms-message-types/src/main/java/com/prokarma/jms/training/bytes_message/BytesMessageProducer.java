package com.prokarma.jms.training.bytes_message;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class BytesMessageProducer {
	// URL of the JMS server.
	private static final String URL = ActiveMQConnection.DEFAULT_BROKER_URL;

	private static String QUEUE_NAME = "SAMPLE_QUEUE";

	public void sendMessage(String messageText) throws JMSException {
		// Getting JMS connection from the server and starting it
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(URL);
		Connection connection = connectionFactory.createConnection();
		connection.start();

		// JMS messages are sent and received using a Session.
		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);

		// Destination represents here our queue 'SAMPLE_QUEUE' on the
		// JMS server. You don't have to do anything special on the
		// server to create it, it will be created automatically.
		Destination destination = session.createQueue(QUEUE_NAME);

		// MessageProducer is used for sending messages
		MessageProducer producer = session.createProducer(destination);

		// There are many types of Message and TextMessage
		// is just one of them.
		BytesMessage message = session.createBytesMessage();
		message.writeBytes(messageText.getBytes());
		// Here we are sending the message!
		producer.send(message);
		System.out.println("Sent message '" + messageText + "'");

		connection.close();
	}

	public static void main(String[] args) throws JMSException {
		BytesMessageProducer producer = new BytesMessageProducer();
		producer.sendMessage("Hello");
	}

}