package com.prokarma.jms.training;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;

public class Consumer {
	// URL of the JMS server.
	private final JmsTemplate template;

	public Consumer(JmsTemplate template) {
		this.template = template;
	}

	public String recieveMessage() {
		try {
			Message message = template.receive();
			if (message instanceof TextMessage) {
				TextMessage textMessage = (TextMessage) message;
				return textMessage.getText();
			}
		} catch (JmsException e) {
			e.printStackTrace();
		} catch (JMSException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) throws InterruptedException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"consumer-context.xml");

		Consumer obj = (Consumer) context.getBean("consumer");
		System.out.println("Received message '" + obj.recieveMessage() + "'");
		Thread.sleep(1000);
		context.close();

	}

}