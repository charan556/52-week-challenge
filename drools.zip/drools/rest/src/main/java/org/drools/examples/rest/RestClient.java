package org.drools.examples.rest;

import org.jboss.resteasy.client.ClientRequest;


public class RestClient {

	public static void main(String[] args) {
		
		ClientRequest request = new ClientRequest("http://localhost:8080/guvnor-5.2.0.Final-tomcat-6.0/rest/packages/examples");
		request = request.accept("");
		System.out.println(request.getBody());
	}

}
