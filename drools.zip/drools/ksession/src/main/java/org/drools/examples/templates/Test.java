package org.drools.examples.templates;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.drools.decisiontable.SpreadsheetCompiler;

public class Test {
	public static void main(String[] args) {
		InputStream is = null;
		try {
			is = new FileInputStream(
					"C:\\Users\\vcharan\\Downloads\\jBPM-Drools-Example-master\\jBPM-Drools-Example-master\\drools\\ksession\\src\\main\\resources\\ExampleCheese.xls");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		SpreadsheetCompiler sc = new SpreadsheetCompiler();
		final String drl = sc.compile(is, "Sheet1");
		// String drl = sc.compile(is, InputType.XLS);
	}
}
