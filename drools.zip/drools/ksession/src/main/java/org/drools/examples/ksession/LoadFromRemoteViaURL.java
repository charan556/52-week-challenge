package org.drools.examples.ksession;

import org.drools.KnowledgeBase;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.io.impl.UrlResource;
import org.drools.runtime.StatefulKnowledgeSession;
import org.prokarma.demo.Car;
import org.prokarma.demo.Driver;

public class LoadFromRemoteViaURL {


	public static void main(String[] args) throws Exception {

		StatefulKnowledgeSession ksession = newKnowledgeSession("http://localhost:8080/guvnor-5.4.0.Final-tomcat-6.0/org.drools.guvnor.Guvnor/package/myNewPackage/LATEST");
		Driver d = new Driver();
		Car c  = new Car();
		d.setAge(19);
		d.setCar(c);
		ksession.insert(d);
		ksession.fireAllRules();
		System.out.println(d.getCar().getColor());
		
		ksession.dispose();
	}
	
	private static StatefulKnowledgeSession newKnowledgeSession(String url) throws Exception {
		UrlResource resource = (UrlResource) ResourceFactory.newUrlResource(url);
		resource.setBasicAuthentication("enabled");
        resource.setUsername("admin");
        resource.setPassword("admin");
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
        kbuilder.add(resource, ResourceType.PKG);
		KnowledgeBase kbase = kbuilder.newKnowledgeBase();
		return kbase.newStatefulKnowledgeSession();
	}


}
